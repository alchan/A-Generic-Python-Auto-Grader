import sys

def function (x):
    return x + x
