def function (x):
    if isinstance (x, int):
        if x > 0:
            return x + x
        else:
            raise ValueError ()
    else:
        raise TypeError ()
